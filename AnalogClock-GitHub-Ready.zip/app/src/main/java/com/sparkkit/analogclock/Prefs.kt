package com.sparkkit.analogclock

import android.content.Context
import android.graphics.Color

/** Clock face designs. */
enum class Design(val label: String) {
    CLASSIC("Classic"),
    MINIMAL("Minimal"),
    ROMAN("Roman"),
    NEON("Neon"),
    MODERN("Modern"),
    PASTEL("Pastel"),
    BOLD("Bold"),
    DOTS("Dots")
}

/** Colour set for one clock. */
data class Palette(
    val name: String,
    val face: Int,
    val rim: Int,
    val tick: Int,
    val hour: Int,
    val minute: Int,
    val second: Int,
    val text: Int
)

val PALETTES: List<Palette> = listOf(
    Palette("Ocean", Color.parseColor("#F5FBFF"), Color.parseColor("#0A6E8C"), Color.parseColor("#0A6E8C"),
        Color.parseColor("#0A6E8C"), Color.parseColor("#1FA2C9"), Color.parseColor("#FF5E7E"), Color.parseColor("#0A3D52")),
    Palette("Sunset", Color.parseColor("#FFF4E8"), Color.parseColor("#FF7A59"), Color.parseColor("#FF7A59"),
        Color.parseColor("#2D1B3D"), Color.parseColor("#FF7A59"), Color.parseColor("#FFB400"), Color.parseColor("#2D1B3D")),
    Palette("Forest", Color.parseColor("#EEF7EE"), Color.parseColor("#2E7D32"), Color.parseColor("#2E7D32"),
        Color.parseColor("#1B4D1E"), Color.parseColor("#43A047"), Color.parseColor("#E53935"), Color.parseColor("#1B4D1E")),
    Palette("Lavender", Color.parseColor("#F3EEFF"), Color.parseColor("#7C5CFF"), Color.parseColor("#7C5CFF"),
        Color.parseColor("#3B2A7A"), Color.parseColor("#7C5CFF"), Color.parseColor("#FF5EA8"), Color.parseColor("#3B2A7A")),
    Palette("Mono", Color.parseColor("#FFFFFF"), Color.parseColor("#111111"), Color.parseColor("#111111"),
        Color.parseColor("#111111"), Color.parseColor("#333333"), Color.parseColor("#E53935"), Color.parseColor("#111111")),
    Palette("Neon", Color.parseColor("#0D0B14"), Color.parseColor("#FF2E88"), Color.parseColor("#00E5FF"),
        Color.parseColor("#FF2E88"), Color.parseColor("#00E5FF"), Color.parseColor("#FFEA00"), Color.parseColor("#F4F1FF")),
    Palette("Gold", Color.parseColor("#1A1409"), Color.parseColor("#D4AF37"), Color.parseColor("#D4AF37"),
        Color.parseColor("#F5D27A"), Color.parseColor("#D4AF37"), Color.parseColor("#FFFFFF"), Color.parseColor("#F5D27A")),
    Palette("Candy", Color.parseColor("#FFE3F0"), Color.parseColor("#FF5EA8"), Color.parseColor("#7C5CFF"),
        Color.parseColor("#7C5CFF"), Color.parseColor("#FF5EA8"), Color.parseColor("#2ED3C6"), Color.parseColor("#5B2A86"))
)

/** Everything needed to draw one clock. */
data class Config(
    val design: Design,
    val palette: Palette,
    val showSeconds: Boolean,
    val showDate: Boolean,
    val showNumbers: Boolean,
    val darkBg: Boolean
)

/** Home screen and lock screen each keep their own settings. */
enum class Screen(val key: String) { HOME("home"), LOCK("lock") }

object Prefs {
    private const val FILE = "sparkclock_prefs"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(c: Context, s: Screen): Config {
        val p = sp(c)
        val k = s.key
        val isLock = s == Screen.LOCK
        val defaultDesign = if (isLock) Design.MINIMAL else Design.CLASSIC
        val designIdx = p.getInt("${k}_design", defaultDesign.ordinal).coerceIn(0, Design.values().size - 1)
        val paletteIdx = p.getInt("${k}_palette", 0).coerceIn(0, PALETTES.size - 1)
        return Config(
            design = Design.values()[designIdx],
            palette = PALETTES[paletteIdx],
            showSeconds = p.getBoolean("${k}_seconds", isLock),
            showDate = p.getBoolean("${k}_date", true),
            showNumbers = p.getBoolean("${k}_numbers", true),
            darkBg = p.getBoolean("${k}_dark", isLock)
        )
    }

    fun save(c: Context, s: Screen, cfg: Config) {
        val k = s.key
        sp(c).edit()
            .putInt("${k}_design", cfg.design.ordinal)
            .putInt("${k}_palette", PALETTES.indexOf(cfg.palette).coerceAtLeast(0))
            .putBoolean("${k}_seconds", cfg.showSeconds)
            .putBoolean("${k}_date", cfg.showDate)
            .putBoolean("${k}_numbers", cfg.showNumbers)
            .putBoolean("${k}_dark", cfg.darkBg)
            .apply()
    }
}
