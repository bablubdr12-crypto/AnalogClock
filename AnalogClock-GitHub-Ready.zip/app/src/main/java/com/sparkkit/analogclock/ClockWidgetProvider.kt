package com.sparkkit.analogclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Home-screen widget. Draws the clock into a bitmap and refreshes once a minute
 * using a repeating alarm (no battery-heavy service). Seconds are not shown on the widget.
 */
class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) updateOne(context, mgr, id)
        scheduleTicks(context)
    }

    override fun onEnabled(context: Context) {
        scheduleTicks(context)
    }

    override fun onDisabled(context: Context) {
        cancelTicks(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) updateAll(context)
    }

    companion object {
        private const val ACTION_TICK = "com.sparkkit.analogclock.TICK"
        private const val SIZE_PX = 360

        /** Called by the app after settings change, so the widget updates immediately. */
        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            for (id in ids) updateOne(context, mgr, id)
        }

        private fun updateOne(context: Context, mgr: AppWidgetManager, id: Int) {
            val cfg = Prefs.load(context, Screen.HOME).copy(showSeconds = false)
            val views = RemoteViews(context.packageName, R.layout.widget_clock)
            views.setImageViewBitmap(R.id.clockImage, ClockRenderer.bitmap(SIZE_PX, cfg))

            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.clockImage, open)
            mgr.updateAppWidget(id, views)
        }

        private fun tickIntent(context: Context): PendingIntent =
            PendingIntent.getBroadcast(
                context, 0,
                Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun scheduleTicks(context: Context) {
            val am = context.getSystemService(AlarmManager::class.java)
            // Align to the next whole minute so the hands jump exactly on time.
            val nextMinute = (System.currentTimeMillis() / 60_000L + 1L) * 60_000L
            am.setRepeating(AlarmManager.RTC, nextMinute, 60_000L, tickIntent(context))
        }

        private fun cancelTicks(context: Context) {
            context.getSystemService(AlarmManager::class.java).cancel(tickIntent(context))
        }
    }
}
