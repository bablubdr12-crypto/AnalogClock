package com.sparkkit.analogclock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val CARD = Color.parseColor("#221D2E")
    private val CARD_ON = Color.parseColor("#FF5EA8")
    private val BG = Color.parseColor("#16131F")
    private val TXT = Color.parseColor("#F4F1FF")
    private val MUTED = Color.parseColor("#A9A2C4")
    private val GOLD = Color.parseColor("#FFD36E")

    private val dp by lazy { resources.displayMetrics.density }
    private fun px(v: Int): Int = (v * dp).toInt()

    private var scope = Screen.HOME
    private lateinit var cfg: Config
    private lateinit var root: LinearLayout

    private lateinit var segHome: TextView
    private lateinit var segLock: TextView
    private lateinit var preview: ImageView
    private val designTiles = mutableListOf<LinearLayout>()
    private val designThumbs = mutableListOf<ImageView>()
    private val paletteSwatches = mutableListOf<View>()
    private lateinit var swSeconds: Switch
    private lateinit var swDate: Switch
    private lateinit var swNumbers: Switch
    private lateinit var swDark: Switch

    // Stops switch listeners from firing while refresh() sets their state.
    private var building = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Prefs.load(this, scope)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(16), px(16), px(28))
            setBackgroundColor(BG)
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })

        root.addView(text("✦ Analog Clock", 22f, TXT, bold = true))
        root.addView(text("Home screen ಮತ್ತು Lock screen ಗೆ ಪ್ರತ್ಯೇಕ ಸೆಟ್ಟಿಂಗ್", 12f, MUTED))

        // Segmented control: Home / Lock
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(4), px(4), px(4), px(4))
            background = roundRect(CARD, 999)
        }
        segHome = segButton("🏠 Home screen") { switchScope(Screen.HOME) }
        segLock = segButton("🔒 Lock screen") { switchScope(Screen.LOCK) }
        seg.addView(segHome, LinearLayout.LayoutParams(0, px(40), 1f))
        seg.addView(segLock, LinearLayout.LayoutParams(0, px(40), 1f))
        root.addView(seg, matchWrap(topMargin = 14))

        // Live preview
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val previewFrame = FrameLayout(this).apply {
            background = roundRect(CARD, 24)
            setPadding(px(12), px(12), px(12), px(12))
            addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        root.addView(previewFrame, LinearLayout.LayoutParams(px(260), px(260)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = px(16)
        })

        // Design grid (4 per row)
        root.addView(text("ಡಿಸೈನ್", 15f, GOLD, bold = true), matchWrap(topMargin = 18))
        val designGrid = GridLayout(this).apply { columnCount = 4 }
        Design.values().forEach { d ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(px(4), px(6), px(4), px(6))
            }
            val thumb = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            tile.addView(thumb, LinearLayout.LayoutParams(px(64), px(64)))
            tile.addView(TextView(this).apply {
                text = d.label
                textSize = 10f
                setTextColor(TXT)
                gravity = Gravity.CENTER
            })
            tile.setOnClickListener { update(cfg.copy(design = d)) }
            designGrid.addView(tile, GridLayout.LayoutParams().apply {
                width = px(84)
                setMargins(px(3), px(3), px(3), px(3))
            })
            designTiles += tile
            designThumbs += thumb
        }
        root.addView(designGrid)

        // Colour grid (4 per row)
        root.addView(text("ರಂಗು", 15f, GOLD, bold = true), matchWrap(topMargin = 18))
        val colourGrid = GridLayout(this).apply { columnCount = 4 }
        PALETTES.forEach { p ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(px(4), px(6), px(4), px(6))
            }
            val swatch = View(this)
            item.addView(swatch, LinearLayout.LayoutParams(px(54), px(54)))
            item.addView(TextView(this).apply {
                text = p.name
                textSize = 10f
                setTextColor(TXT)
                gravity = Gravity.CENTER
            })
            item.setOnClickListener { update(cfg.copy(palette = p)) }
            colourGrid.addView(item, GridLayout.LayoutParams().apply {
                width = px(84)
                setMargins(px(3), px(3), px(3), px(3))
            })
            paletteSwatches += swatch
        }
        root.addView(colourGrid)

        // Toggles
        root.addView(text("ಆಯ್ಕೆಗಳು", 15f, GOLD, bold = true), matchWrap(topMargin = 18))
        swSeconds = switchRow("ಸೆಕೆಂಡ್ ಮುಳ್ಳು") { if (!building) update(cfg.copy(showSeconds = it)) }
        swDate = switchRow("ದಿನಾಂಕ ತೋರಿಸು") { if (!building) update(cfg.copy(showDate = it)) }
        swNumbers = switchRow("ಅಂಕಿಗಳು ತೋರಿಸು") { if (!building) update(cfg.copy(showNumbers = it)) }
        swDark = switchRow("ಕಪ್ಪು ಹಿನ್ನೆಲೆ") { if (!building) update(cfg.copy(darkBg = it)) }

        // Actions
        root.addView(text("ಹಂತಗಳು", 15f, GOLD, bold = true), matchWrap(topMargin = 18))
        root.addView(actionButton("🔒 Lock-screen clock ತೆರೆ") {
            startActivity(Intent(this, LockScreenActivity::class.java))
        }, matchWrap(topMargin = 6))
        root.addView(text(
            "Home screen ಖಾಲಿ ಜಾಗದಲ್ಲಿ ಒತ್ತಿ ಹಿಡಿಯಿರಿ → Widgets → Analog Clock ಆಯ್ಕೆ ಮಾಡಿ. " +
                "ಬದಲಾವಣೆಗಳು widget ನಲ್ಲಿ ತಕ್ಷಣ ಕಾಣಿಸುತ್ತವೆ.",
            11f, MUTED
        ), matchWrap(topMargin = 8))
        root.addView(text(
            "ಗಮನಿಸಿ: Android ಅನುಮತಿಸದ ಕಾರಣ third-party clock ನೇರವಾಗಿ ಫೋನ್‌ನ lock screen ನಲ್ಲಿ ಇರಿಸಲಾಗದು. " +
                "Lock-screen clock ಬಟನ್ ಅದೇ ವಿನ್ಯಾಸವನ್ನು ಲಾಕ್ ಆದ ಮೇಲೆಯೂ ತೋರಿಸುತ್ತದೆ.",
            11f, MUTED
        ), matchWrap(topMargin = 6))

        refresh()
    }

    override fun onResume() {
        super.onResume()
        cfg = Prefs.load(this, scope)
        refresh()
    }

    private fun switchScope(s: Screen) {
        scope = s
        cfg = Prefs.load(this, s)
        refresh()
    }

    private fun update(newCfg: Config) {
        cfg = newCfg
        Prefs.save(this, scope, newCfg)
        if (scope == Screen.HOME) ClockWidgetProvider.updateAll(this)
        refresh()
    }

    private fun refresh() {
        building = true

        segHome.background = roundRect(if (scope == Screen.HOME) CARD_ON else Color.TRANSPARENT, 999)
        segLock.background = roundRect(if (scope == Screen.LOCK) CARD_ON else Color.TRANSPARENT, 999)
        segHome.setTextColor(if (scope == Screen.HOME) Color.WHITE else MUTED)
        segLock.setTextColor(if (scope == Screen.LOCK) Color.WHITE else MUTED)

        preview.setImageBitmap(ClockRenderer.bitmap(520, cfg.copy(showSeconds = true)))

        Design.values().forEachIndexed { i, d ->
            val selected = d == cfg.design
            designTiles[i].background = roundRect(if (selected) CARD_ON else CARD, 16)
            designThumbs[i].setImageBitmap(
                ClockRenderer.bitmap(160, cfg.copy(design = d, showSeconds = false, showDate = false))
            )
        }

        PALETTES.forEachIndexed { i, p ->
            val selected = p == cfg.palette
            paletteSwatches[i].background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(p.face)
                setStroke(px(if (selected) 4 else 2), if (selected) Color.WHITE else p.rim)
            }
        }

        swSeconds.isChecked = cfg.showSeconds
        swDate.isChecked = cfg.showDate
        swNumbers.isChecked = cfg.showNumbers
        swDark.isChecked = cfg.darkBg

        building = false
    }

    // ---------- small UI helpers ----------

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, px(4), 0, px(4))
        }

    private fun segButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
        }

    private fun switchRow(label: String, onChange: (Boolean) -> Unit): Switch {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(14), px(10), px(14), px(10))
            background = roundRect(CARD, 14)
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(TXT)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(sw)
        root.addView(row, matchWrap(topMargin = 6))
        return sw
    }

    private fun actionButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(px(14), px(14), px(14), px(14))
            background = roundRect(CARD_ON, 16)
            setOnClickListener { onClick() }
        }

    private fun roundRect(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = px(radiusDp).toFloat()
            setColor(color)
        }

    private fun matchWrap(topMargin: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { this.topMargin = px(topMargin) }

}
