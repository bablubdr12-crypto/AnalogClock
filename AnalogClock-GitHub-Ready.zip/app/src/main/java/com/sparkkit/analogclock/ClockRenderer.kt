package com.sparkkit.analogclock

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Per-design proportions. Widths are fractions of the clock radius. */
private data class Spec(
    val hourW: Float,
    val minW: Float,
    val secW: Float,
    val glow: Boolean,
    val minimal: Boolean,
    val dots: Boolean,
    val boldText: Boolean
)

/**
 * Draws the analog clock onto any Canvas. Used by the in-app preview,
 * the lock-screen view (through ClockView) and the home-screen widget (through bitmap()).
 */
object ClockRenderer {

    private val ROMAN = arrayOf("XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI")

    private fun spec(d: Design): Spec = when (d) {
        Design.CLASSIC -> Spec(0.060f, 0.040f, 0.014f, glow = false, minimal = false, dots = false, boldText = false)
        Design.MINIMAL -> Spec(0.030f, 0.020f, 0.008f, glow = false, minimal = true, dots = false, boldText = false)
        Design.ROMAN   -> Spec(0.050f, 0.032f, 0.012f, glow = false, minimal = false, dots = false, boldText = false)
        Design.NEON    -> Spec(0.050f, 0.034f, 0.012f, glow = true, minimal = false, dots = false, boldText = true)
        Design.MODERN  -> Spec(0.075f, 0.048f, 0.014f, glow = false, minimal = false, dots = false, boldText = true)
        Design.PASTEL  -> Spec(0.065f, 0.045f, 0.020f, glow = false, minimal = false, dots = false, boldText = false)
        Design.BOLD    -> Spec(0.090f, 0.060f, 0.020f, glow = false, minimal = false, dots = false, boldText = true)
        Design.DOTS    -> Spec(0.050f, 0.035f, 0.012f, glow = false, minimal = false, dots = true, boldText = false)
    }

    fun bitmap(size: Int, cfg: Config): Bitmap {
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        draw(Canvas(bm), size.toFloat(), size.toFloat(), Calendar.getInstance(), cfg)
        return bm
    }

    fun draw(c: Canvas, w: Float, h: Float, cal: Calendar, cfg: Config) {
        val p = cfg.palette
        val s = spec(cfg.design)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f * 0.94f

        if (cfg.darkBg) c.drawColor(Color.BLACK)

        // Face and rim
        c.drawCircle(cx, cy, r, paint(p.face, Paint.Style.FILL))
        c.drawCircle(cx, cy, r * 0.97f, paint(p.rim, Paint.Style.STROKE, r * 0.035f, s.glow))

        // Ticks or dots
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val major = i % 5 == 0
            if (s.dots) {
                val rad = if (major) r * 0.035f else r * 0.014f
                c.drawCircle(ox(cx, r * 0.86f, a), oy(cy, r * 0.86f, a), rad, paint(p.tick, Paint.Style.FILL))
            } else if (!s.minimal || major) {
                val width = if (major) r * 0.035f else r * 0.014f
                val inner = if (major) r * 0.80f else r * 0.88f
                c.drawLine(
                    ox(cx, r * 0.95f, a), oy(cy, r * 0.95f, a),
                    ox(cx, inner, a), oy(cy, inner, a),
                    paint(p.tick, Paint.Style.STROKE, width)
                )
            }
        }

        // Numerals (Arabic, or Roman for the Roman design)
        if (cfg.showNumbers && !s.minimal) {
            val size = r * (if (s.boldText) 0.22f else 0.15f)
            val tp = paint(p.text, Paint.Style.FILL, glow = s.glow).apply {
                textAlign = Paint.Align.CENTER
                textSize = size
                typeface = when {
                    cfg.design == Design.ROMAN -> Typeface.create("serif", Typeface.NORMAL)
                    s.boldText -> Typeface.DEFAULT_BOLD
                    else -> Typeface.DEFAULT
                }
            }
            for (n in 1..12) {
                val a = Math.toRadians(n * 30.0)
                val label = if (cfg.design == Design.ROMAN) ROMAN[n % 12] else n.toString()
                c.drawText(label, ox(cx, r * 0.66f, a), oy(cy, r * 0.66f, a) + size * 0.35f, tp)
            }
        }

        // Date window
        if (cfg.showDate) {
            val dp = paint(p.text, Paint.Style.FILL).apply {
                textAlign = Paint.Align.CENTER
                textSize = r * 0.11f
                typeface = Typeface.DEFAULT_BOLD
                alpha = 200
            }
            val label = SimpleDateFormat("EEE d", Locale.getDefault()).format(cal.time)
            c.drawText(label, cx, cy + r * 0.42f, dp)
        }

        // Hands (angles in degrees, converted to radians in hand())
        val hourDeg = (cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60f + cal.get(Calendar.SECOND) / 3600f) * 30.0
        val minDeg = (cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f + cal.get(Calendar.MILLISECOND) / 60000f) * 6.0
        val secDeg = (cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f) * 6.0

        hand(c, cx, cy, r * 0.52f, r * 0.10f, s.hourW * r, p.hour, Math.toRadians(hourDeg), s.glow)
        hand(c, cx, cy, r * 0.76f, r * 0.12f, s.minW * r, p.minute, Math.toRadians(minDeg), s.glow)
        if (cfg.showSeconds) {
            hand(c, cx, cy, r * 0.86f, r * 0.22f, s.secW * r, p.second, Math.toRadians(secDeg), s.glow)
        }

        // Centre cap
        c.drawCircle(cx, cy, max(r * 0.035f, 2f), paint(p.second, Paint.Style.FILL, glow = s.glow))
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, len: Float, tail: Float, width: Float, color: Int, a: Double, glow: Boolean) {
        val p = paint(color, Paint.Style.STROKE, width, glow)
        c.drawLine(ox(cx, -tail, a), oy(cy, -tail, a), ox(cx, len, a), oy(cy, len, a), p)
    }

    private fun paint(color: Int, style: Paint.Style, strokeW: Float = 0f, glow: Boolean = false): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.style = style
            strokeCap = Paint.Cap.ROUND
            if (style == Paint.Style.STROKE) strokeWidth = strokeW
            if (glow) setShadowLayer(max(strokeW, 6f) * 1.5f, 0f, 0f, color)
        }

    // Point at distance len from centre, angle a measured clockwise from 12 o'clock.
    private fun ox(cx: Float, len: Float, a: Double): Float = (cx + len * sin(a)).toFloat()
    private fun oy(cy: Float, len: Float, a: Double): Float = (cy - len * cos(a)).toFloat()
}
